/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Collection;
import java.util.LinkedList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author joaqu
 */
public class TGrafoNoDirigidoTest {
    
    TAristas lasPeliculas = new TAristas(); 
    LinkedList<TVertice> losActores = new LinkedList<>();
    
    @Before
    public void setUp() {
        

        lasPeliculas.add(new TArista("Kevin_Bacon","Harrison_Ford",1));
        lasPeliculas.add(new TArista("Kevin_Bacon","Carrie_Fisher",1));
        lasPeliculas.add(new TArista("Kevin_Bacon","Peter_Cushing",1));
       

        losActores.add(new TVertice("Kevin_Bacon"));
        losActores.add(new TVertice("Harrison_Ford"));
        losActores.add(new TVertice("Carrie_Fisher"));
        losActores.add(new TVertice("Peter_Cushing"));
        losActores.add(new TVertice("Anthony_Daniels"));

        
    }
    
    @Test
    public void test1() {
        System.out.println("Test 1");
        TGrafoNoDirigido gd = new TGrafoNoDirigido(losActores, lasPeliculas);                
        int expResult = 0;
        int resultado = gd.listarContactos("Kevin_Bacon", 1).size();
        assertEquals(expResult, resultado);
    }
    @Test
    public void test2() {
        System.out.println("Test 2");
        TGrafoNoDirigido gd = new TGrafoNoDirigido(losActores, lasPeliculas);                
        int expResult = 1;
        int resultado = gd.listarContactos("Harrison_Ford", 1).size();
        assertEquals(expResult, resultado);
    }
    
}
