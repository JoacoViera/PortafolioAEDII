
import java.util.Collection;
import java.util.LinkedList;

public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

// cargar grafo con actores y relaciones
        String[] aristas = ManejadorArchivosGenerico.leerArchivo("src/en_pelicula.txt", false);
        String[] datos = null;
        TAristas lasPeliculas = new TAristas();
        for (String arista : aristas) {
            datos = arista.split(",");
            if (datos.length == 3){
                if (Character.isDigit(datos[2].charAt(0))) {               
                    lasPeliculas.add(new TArista(datos[0],datos[1],Double.parseDouble(datos[2])));
                } else{
                    lasPeliculas.add(new TArista(datos[0],datos[1],1));
                }
            }          
        }

        String[] vert = ManejadorArchivosGenerico.leerArchivo("src/actores.txt", false);
        LinkedList<TVertice> losActores = new LinkedList<>();
        for (String vertices : vert) {
            datos = vertices.split(",");
            losActores.add(new TVertice(datos[0]));
        }

        
        TGrafoNoDirigido gkb = new TGrafoNoDirigido(losActores, lasPeliculas);

        
     
        //Kevin_Bacon
        //David_Cross
        String actorZZ1 = "Kevin_Bacon"; // se indicará en el pizarrón
        Collection<TVertice> contactos1 = gkb.listarContactos(actorZZ1, 1);
        System.out.println(contactos1.size());
        // escribir los resultados al archivo "salida.txt"

        String actorZZ2 = "David_Cross"; // se indicará en el pizarrón
        Collection<TVertice> contactos2 = gkb.listarContactos(actorZZ2, 5);
        System.out.println(contactos2.size());

        // escribir los resultados al archivo "salida.txt"
        

        
        
        // emitir un archivo de salida, "salida.txt" con la lista de contactos obtenida
    }
}
