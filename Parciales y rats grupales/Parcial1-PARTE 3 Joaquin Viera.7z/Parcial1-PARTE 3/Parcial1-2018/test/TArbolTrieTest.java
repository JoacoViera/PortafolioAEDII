/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Collection;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author joaqu
 */
public class TArbolTrieTest {
    
   private TArbolTrie trie;
    
    @Before
    public void setUp() {
        trie = new TArbolTrie();
        TDispositivo a1 = new TDispositivo("255110652199","Dispositivo1","");
        TDispositivo a2 = new TDispositivo("255153858199","Dispositivo2","");
        TDispositivo a3 = new TDispositivo("255243241199","Dispositivo3","");
        trie.insertar(a1);
        trie.insertar(a2);
        trie.insertar(a3);
        
    }
    
    //TEST LISTA CON ELEMENTOS
    @Test
    public void testPredecir() {
        System.out.println("Test 1");
        String prefijo = "255";
        Collection<TDispositivo> result = trie.buscarDispositivos(prefijo);
        assertEquals(3, result.size());
    }
    
    //TEST LISTA VACIA, OSEA NULL
    @Test
    public void testPredecir2() {
        System.out.println("Test 1");
        String prefijo = "658";
        Collection<TDispositivo> result = trie.buscarDispositivos(prefijo);
        
        assertEquals(null, result);
    }
    
}
