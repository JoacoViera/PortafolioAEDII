

import java.util.Collection;


public class Main {

    /**
     * @param args
     */
    public static void main(String[] args){
        TArbolTrie trie = new TArbolTrie();

        String[] archivo = ManejadorArchivosGenerico.leerArchivo("./src/dispositivos.txt");
        for (String renglon : archivo) {  
            
            String[] linea = renglon.split(",");
            String dirIP = linea[0];
            String nombre = linea[1];

            String nuevaIP = "";         
            for(int c=0 ;c<dirIP.length();c++){
                if(dirIP.charAt(c) != '.'){
                     nuevaIP += dirIP.charAt(c);
                }
            }
            if(nuevaIP.length() == 12){
                TDispositivo nodo = new TDispositivo(nuevaIP,nombre,"");
            
                trie.insertar(nodo);
            }                              
        }

       // CARGAR EN EL TRIE LOS DISPOSITIVOS PARTIR DEL ARCHIVO DISPOSITIVOS.TXT
        
        
        String subRed = "207" ; // utilizar el indicado en el archivo "subredes.txt"
        
        Collection<TDispositivo> dispositivos = trie.buscarDispositivos(subRed);
        String[] res = new String[dispositivos.size()];
        int cont = 0;
        for (TDispositivo t : dispositivos){
            System.out.println(t.getNombre());
            res[cont] = t.getNombre();
            cont++;
        }
        
        // crear el archivo "salida.txt", con los dispositivos(1 por linea) 
        // correspondientes a la subred indicada
        // imprimir Nombre y dirección de  IP, 
        
        
        
        ManejadorArchivosGenerico.escribirArchivo("./src/salida.txt",res);
       
        
        
    }
}