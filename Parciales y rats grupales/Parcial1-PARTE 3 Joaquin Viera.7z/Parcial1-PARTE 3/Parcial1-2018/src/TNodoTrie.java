
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joaqu
 */
public class TNodoTrie implements INodoTrie {
    
    private static final int CANT_CHR_ABECEDARIO = 10;
    //private static final int[] numeros = {0,1,2,3,4,5,6,7,8,9};
    private final TNodoTrie[] hijos;
    private boolean esPalabra;
    private TDispositivo dato;
    
    public TNodoTrie() {
        hijos = new TNodoTrie[CANT_CHR_ABECEDARIO];
        esPalabra = false;
        dato=null;
    }

    @Override
    public void insertar(TDispositivo unDispositivo) {
        TNodoTrie nodo = this;
        for (int c = 0; c < unDispositivo.getDirIP().length(); c++) {
            int indice = unDispositivo.getDirIP().charAt(c) - '0';
            try{
                if (nodo.hijos[indice] == null) {
                    nodo.hijos[indice] = new TNodoTrie();
                }
            nodo = nodo.hijos[indice];
            }catch(Exception e) {
                System.err.println("No se pueden insertar palabras con caracteres que no sean letras");
            }
        }
        nodo.esPalabra = true;
        nodo.dato = unDispositivo;
           
    }
    
    
    public void buscarDispositivos(String primerosDigitos, LinkedList<TDispositivo> dispositivos) {  
        if (this != null) {
            if (this.esPalabra) {
                dispositivos.add(this.dato);
            }
            for (int c = 0; c < CANT_CHR_ABECEDARIO; c++) {
                if (this.hijos[c] != null) {
                    char letra = (char) ((c) + '0');
                    imprimir(primerosDigitos+letra, this.hijos[c], dispositivos);                   
                }
            }
        }
    }
    
    private void imprimir(String s, TNodoTrie nodo,LinkedList<TDispositivo> dispositivos) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                //System.out.println(s + " " + nodo.dato.getNombre()); 
                dispositivos.add(nodo.dato);
            }
            for (int c = 0; c < CANT_CHR_ABECEDARIO; c++) {
                if (nodo.hijos[c] != null) {
                    char letra = (char) ((c) + '0');
                    imprimir(s+letra, nodo.hijos[c], dispositivos);
                    
                }
            }
        }
    }
    
    public TNodoTrie buscarPrefijo(String prefijo){
       TNodoTrie nodo = this;
       for (int c = 0; c < prefijo.length(); c++) {
           int indice = prefijo.charAt(c) - '0';
           if (nodo.hijos[indice] == null) {
               return null;
           }
           nodo = nodo.hijos[indice];
       }       
       return nodo; 
   }
    
}
